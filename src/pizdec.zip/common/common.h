#ifndef COMMON_H
#define COMMON_H

#include <QString>

extern const QChar separator;
QString& operator<< (QString&,const QString&);

#endif // COMMON_H
